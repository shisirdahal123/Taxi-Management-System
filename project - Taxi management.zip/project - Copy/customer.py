import tkinter as tk
from tkinter import messagebox
import data
import ui_helpers as ui
from datetime import datetime


def customer_register(app):
    """Render the registration card for customers. Uses `app.root`."""
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    # Heading area
    heading = tk.Label(root, text="Customer Registration", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY)
    heading.place(relx=0.5, rely=0.13, anchor='c')

    card = tk.Frame(root, bg=ui.CARD_BG)
    card.place(relx=0.5, rely=0.55, anchor='c', width=460, height=240)

    frm = tk.Frame(card, bg=ui.CARD_BG)
    frm.pack(padx=12, pady=10, fill='both', expand=True)

    tk.Label(frm, text="Email", bg=ui.CARD_BG, anchor='w').pack(fill='x')
    email_entry = tk.Entry(frm, font=ui.NORMAL_FONT)
    email_entry.pack(fill='x', pady=(4, 8))

    tk.Label(frm, text="Password", bg=ui.CARD_BG, anchor='w').pack(fill='x')
    pw_row = tk.Frame(frm, bg=ui.CARD_BG)
    pw_row.pack(fill='x')
    pass_entry = tk.Entry(pw_row, show='*', font=ui.NORMAL_FONT)
    pass_entry.pack(side='left', fill='x', expand=True, pady=(4, 8))

    def _toggle():
        if pass_entry.cget('show') == '*':
            pass_entry.config(show='')
            toggle.config(text='Hide')
        else:
            pass_entry.config(show='*')
            toggle.config(text='Show')

    toggle = tk.Button(pw_row, text='Show', bg='#eee', bd=0, command=_toggle)
    toggle.pack(side='left', padx=(6,0), pady=(4,8))

    def register():
        email = email_entry.get().strip()
        pwd = pass_entry.get().strip()
        if not email or not pwd:
            messagebox.showwarning("Warning", "All fields required")
            return
        if email in data.users_db:
            messagebox.showerror("Error", "User already exists")
            return
        if data.add_user(email, pwd):
            messagebox.showinfo("Success", "Registration Complete")
            app.customer_login()
        else:
            messagebox.showerror("Error", "Registration failed")

    btn_row = tk.Frame(frm, bg=ui.CARD_BG)
    btn_row.pack(pady=(12,0))
    tk.Button(btn_row, text="Register", bg=ui.ACCENT, fg=ui.BTN_FG, command=register, bd=0, width=12).pack(side='left', padx=8)
    back_btn = ui.make_back(btn_row, "Back", app.customer_login)
    back_btn.pack(side='left', padx=8)


def customer_dashboard(app, email):
    # Validate user is still logged in
    current = data.get_current_user()
    if current["type"] != "customer" or current["name"] != email:
        messagebox.showerror("Error", "Session expired. Please login again.")
        app.main_screen()
        return
    
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text=f"Welcome {email}", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=15)

    tk.Button(root, text="Book Taxi", width=25, command=lambda: book_taxi(app, email), bg=ui.PRIMARY, fg=ui.BTN_FG, bd=0).pack(pady=5)
    tk.Button(root, text="View Bookings", width=25, command=lambda: view_customer_bookings(app, email), bg=ui.ACCENT, fg=ui.BTN_FG, bd=0).pack(pady=5)
    tk.Button(root, text="Logout", width=25, command=app.main_screen, bd=0).pack(pady=20)


def book_taxi(app, email):
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text="Taxi Booking", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=15)

    tk.Label(root, text="Pickup Location", bg=ui.BG).pack()
    pickup = tk.Entry(root)
    pickup.pack()

    tk.Label(root, text="Drop Location", bg=ui.BG).pack()
    drop = tk.Entry(root)
    drop.pack()

    # Date and Time inputs with format hints
    tk.Label(root, text="Date (YYYY-MM-DD)", bg=ui.BG).pack()
    date_entry = tk.Entry(root)
    date_entry.pack()

    tk.Label(root, text="Time (HH:MM, 24-hour)", bg=ui.BG).pack()
    time_entry = tk.Entry(root)
    time_entry.pack()

    tk.Label(root, text="Example: 2025-11-27 14:30", bg=ui.BG, font=getattr(ui, 'SUB_FONT', ui.NORMAL_FONT), fg=ui.PRIMARY).pack(pady=(4,6))

    def confirm():
        pickup_v = pickup.get().strip()
        drop_v = drop.get().strip()
        date_v = date_entry.get().strip()
        time_v = time_entry.get().strip()
        if not pickup_v or not drop_v or not date_v or not time_v:
            messagebox.showwarning("Warning", "All fields required")
            return
        # validate date/time
        try:
            dt = datetime.strptime(f"{date_v} {time_v}", "%Y-%m-%d %H:%M")
            date_str = dt.strftime("%Y-%m-%d %H:%M")
        except Exception:
            messagebox.showerror("Invalid", "Please enter date as YYYY-MM-DD and time as HH:MM (24-hour)")
            return

        booking = {
            "customer": email,
            "pickup": pickup_v,
            "drop": drop_v,
            "date": date_str,
            "driver": "Not Assigned",
            "status": "Pending"
        }
        data.add_booking(email, pickup_v, drop_v, date_str)
        messagebox.showinfo("Success", "Taxi Booked Successfully")
        customer_dashboard(app, email)

    tk.Button(root, text="Confirm Booking", command=confirm).pack(pady=15)
    bottom = tk.Frame(root, bg=ui.BG)
    bottom.pack(side='bottom', pady=8)
    ui.make_back(bottom, "Back", lambda: customer_dashboard(app, email)).pack()


def view_customer_bookings(app, email):
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text="My Bookings", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=10)

    box_frame = tk.Frame(root)
    box_frame.pack(padx=12, pady=6, fill='both', expand=True)

    scrollbar = tk.Scrollbar(box_frame)
    scrollbar.pack(side='right', fill='y')

    listbox = tk.Listbox(box_frame, yscrollcommand=scrollbar.set, font=ui.NORMAL_FONT)
    listbox.pack(fill='both', expand=True)
    scrollbar.config(command=listbox.yview)

    items = data.users_db[email].get('bookings', [])
    if not items:
        listbox.insert(tk.END, 'No bookings yet')
    else:
        for b in items:
            listbox.insert(tk.END, f"{b['pickup']} → {b['drop']} | {b['date']} | {b['status']}")

    bottom = tk.Frame(root, bg=ui.BG)
    bottom.pack(side='bottom', pady=8)
    ui.make_back(bottom, "Back", lambda: customer_dashboard(app, email)).pack()
