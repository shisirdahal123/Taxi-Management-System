import tkinter as tk
from tkinter import messagebox
import data
import ui_helpers as ui


def driver_dashboard(app, driver):
    # Ensure current_user reflects this driver. If not, set it.
    current = data.get_current_user()
    if current.get("type") != "driver" or current.get("name") != driver:
        # Instead of blocking, update the session so the driver can continue.
        data.set_current_user("driver", driver)
    
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text=f"Driver: {driver}", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=10)

    # Section: Unassigned bookings
    tk.Label(root, text="Available Bookings", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=(8, 2))
    box = tk.Frame(root, bg=ui.CARD_BG)
    box.pack(padx=12, pady=6, fill='both', expand=False)
    sb = tk.Scrollbar(box)
    sb.pack(side='right', fill='y')
    lb = tk.Listbox(box, yscrollcommand=sb.set, font=ui.NORMAL_FONT, width=60, height=5)
    lb.pack(side='left', fill='both', expand=True)
    sb.config(command=lb.yview)

    # List unassigned bookings
    unassigned = [b for b in data.bookings if b['driver'] == 'Not Assigned' and b['status'] == 'Pending']
    for i, b in enumerate(unassigned):
        lb.insert(tk.END, f"{i+1}. {b['customer']} | {b['pickup']}→{b['drop']} | {b['date']}")

    def accept():
        sel = lb.curselection()
        if not sel:
            tk.messagebox.showwarning('Select', 'Please select a booking to accept')
            return
        idx = sel[0]
        booking = unassigned[idx]
        booking['driver'] = driver
        booking['status'] = 'Accepted'
        data.drivers_db[driver]['assigned'].append(booking)
        tk.messagebox.showinfo('Accepted', 'Booking accepted!')
        driver_dashboard(app, driver)

    tk.Button(root, text="Accept Booking", command=accept, bg=ui.ACCENT, fg=ui.BTN_FG, bd=0).pack(pady=6)

    # Section: View assigned trips
    tk.Button(root, text="View Assigned Trips", width=25, command=lambda: driver_view_trips(app, driver), bg=ui.PRIMARY, fg=ui.BTN_FG, bd=0).pack(pady=10)
    tk.Button(root, text="Logout", command=app.main_screen, bd=0).pack(pady=20)


def driver_view_trips(app, driver):
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    # Heading area
    heading = tk.Label(root, text="Assigned Trips", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY)
    heading.place(relx=0.5, rely=0.08, anchor='c')

    box = tk.Frame(root)
    box.pack(padx=12, pady=6, fill='both', expand=True)
    sb = tk.Scrollbar(box)
    sb.pack(side='right', fill='y')
    lb = tk.Listbox(box, yscrollcommand=sb.set, font=ui.NORMAL_FONT)
    lb.pack(fill='both', expand=True)
    sb.config(command=lb.yview)

    assigned = data.drivers_db.get(driver, {}).get('assigned', [])
    if not assigned:
        lb.insert(tk.END, 'No trips assigned')
    else:
        for b in assigned:
            lb.insert(tk.END, f"{b['pickup']} → {b['drop']} | {b['date']} | {b['status']}")

    bottom = tk.Frame(root, bg=ui.BG)
    bottom.pack(side='bottom', pady=8)
    ui.make_back(bottom, "Back", lambda: driver_dashboard(app, driver)).pack()


# -------------------- DRIVER REGISTER --------------------
def driver_register(app):
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    # Heading area
    heading = tk.Label(root, text="Driver Registration", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY)
    heading.place(relx=0.5, rely=0.13, anchor='c')

    card = tk.Frame(root, bg=ui.CARD_BG)
    card.place(relx=0.5, rely=0.55, anchor='c', width=420, height=220)

    frm = tk.Frame(card, bg=ui.CARD_BG)
    frm.pack(padx=16, pady=12, fill='both', expand=True)

    tk.Label(frm, text="Username", bg=ui.CARD_BG, anchor='w', font=ui.NORMAL_FONT).pack(fill='x')
    user_entry = tk.Entry(frm, font=ui.NORMAL_FONT)
    user_entry.pack(fill='x', pady=(4, 8))

    tk.Label(frm, text="Password", bg=ui.CARD_BG, anchor='w', font=ui.NORMAL_FONT).pack(fill='x')
    pass_entry = tk.Entry(frm, show='*', font=ui.NORMAL_FONT)
    pass_entry.pack(fill='x', pady=(4, 8))

    def register():
        user = user_entry.get().strip()
        pwd = pass_entry.get()
        if not user or not pwd:
            tk.messagebox.showerror("Error", "All fields required")
            return
        if user in data.drivers_db:
            tk.messagebox.showerror("Error", "Driver already exists")
            return
        if data.add_driver(user, pwd):
            tk.messagebox.showinfo("Success", "Driver registered. You can now login.")
            app.driver_login()
        else:
            tk.messagebox.showerror("Error", "Registration failed")

    btn_row = tk.Frame(frm, bg=ui.CARD_BG)
    btn_row.pack(pady=(12, 0))
    reg_btn = tk.Button(btn_row, text="Register", bg=ui.PRIMARY, fg=ui.BTN_FG, width=12, bd=0, command=register)
    reg_btn.pack(side='left', padx=8)
    clear_btn = tk.Button(btn_row, text="Clear", bg=ui.ACCENT, fg=ui.BTN_FG, width=12, bd=0, command=lambda: (user_entry.delete(0, tk.END), pass_entry.delete(0, tk.END), user_entry.focus()))
    clear_btn.pack(side='left', padx=8)
    back_btn = tk.Button(btn_row, text='Back', bg='#fafafa', bd=0, width=12, command=app.driver_login)
    back_btn.pack(side='left', padx=8)
    ui.make_hover(reg_btn, '#8b3bd1')
    ui.make_hover(clear_btn, '#9b6df0')
