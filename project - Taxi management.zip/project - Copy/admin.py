import tkinter as tk
from tkinter import messagebox
import data
import ui_helpers as ui


def admin_dashboard(app):
    # Validate user is still logged in
    current = data.get_current_user()
    if current["type"] != "admin":
        messagebox.showerror("Error", "Session expired. Please login again.")
        app.main_screen()
        return
    
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text="Admin Dashboard", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=15)

    tk.Button(root, text="View All Bookings", width=25, command=lambda: admin_view_bookings(app), bg=ui.PRIMARY, fg=ui.BTN_FG, bd=0).pack(pady=5)
    tk.Button(root, text="Logout", width=25, command=app.main_screen, bd=0).pack(pady=20)


def admin_view_bookings(app):
    root = app.root
    for w in root.winfo_children():
        w.destroy()

    tk.Label(root, text="Assign Driver", font=ui.HEAD_FONT, bg=ui.BG, fg=ui.PRIMARY).pack(pady=10)

    box = tk.Frame(root)
    box.pack(padx=12, pady=6, fill='both', expand=True)
    lb_scroll = tk.Scrollbar(box)
    lb_scroll.pack(side='right', fill='y')
    lb = tk.Listbox(box, yscrollcommand=lb_scroll.set, font=ui.NORMAL_FONT)
    lb.pack(fill='both', expand=True)
    lb_scroll.config(command=lb.yview)

    for i, b in enumerate(data.bookings):
        lb.insert(tk.END, f"{i+1}. {b['customer']} | {b['pickup']}→{b['drop']} | {b['status']}")

    tk.Label(root, text='Select driver', bg=ui.BG).pack()
    driver_var = tk.StringVar(value=list(data.drivers_db.keys())[0] if data.drivers_db else '')
    driver_menu = tk.OptionMenu(root, driver_var, *data.drivers_db.keys())
    driver_menu.config(width=20)
    driver_menu.pack()

    def assign():
        sel = lb.curselection()
        if not sel:
            messagebox.showwarning('Select', 'Please select a booking from the list')
            return
        idx = sel[0]
        chosen_driver = driver_var.get()
        if chosen_driver not in data.drivers_db:
            messagebox.showerror('Driver', 'No driver selected')
            return
        booking = data.bookings[idx]
        booking_id = booking.get('id')
        if booking_id:
            data.assign_booking(booking_id, chosen_driver)
        messagebox.showinfo('Success', f'Driver {chosen_driver} assigned')
        app.admin_dashboard()

    tk.Button(root, text="Assign Driver", command=assign, bg=ui.ACCENT, fg=ui.BTN_FG, bd=0).pack(pady=8)
    bottom = tk.Frame(root, bg=ui.BG)
    bottom.pack(side='bottom', pady=8)
    ui.make_back(bottom, "Back", app.admin_dashboard).pack()
