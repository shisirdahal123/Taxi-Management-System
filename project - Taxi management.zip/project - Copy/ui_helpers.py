import tkinter as tk

# Theme constants used across modules
PRIMARY = "#6A0DAE"
ACCENT = "#8A2BE2"
BG = "#F6F0FF"
CARD_BG = "#ffffff"
BTN_FG = "#ffffff"
HEAD_FONT = ("Segoe UI", 20, "bold")
NORMAL_FONT = ("Segoe UI", 12)
SUB_FONT = ("Segoe UI", 10)


def make_hover(widget, hover_bg):
    """Simple hover effect for Buttons."""
    try:
        orig = widget.cget('bg')
    except Exception:
        orig = None

    def _on(e):
        try:
            widget.configure(bg=hover_bg)
        except Exception:
            pass

    def _off(e):
        try:
            widget.configure(bg=orig)
        except Exception:
            pass

    widget.bind('<Enter>', _on)
    widget.bind('<Leave>', _off)


def center(win: tk.Tk, w: int = 540, h: int = 380) -> None:
    win.geometry(f"{w}x{h}")
    win.update_idletasks()
    x = (win.winfo_screenwidth() - w) // 2
    y = (win.winfo_screenheight() - h) // 2
    win.geometry(f"{w}x{h}+{x}+{y}")


# Back button styling helper
BACK_BG = '#fafafa'
BACK_WIDTH = 12
BACK_HOVER = '#f0f0f0'

def make_back(parent, text, command, width=None):
    """Create a consistently styled Back-like button and attach hover."""
    w = width or BACK_WIDTH
    btn = tk.Button(parent, text=text, bg=BACK_BG, bd=0, width=w, command=command)
    make_hover(btn, BACK_HOVER)
    return btn


# --- New UI factories for consistent styling ---
BTN_PRIMARY = PRIMARY
BTN_ACCENT = ACCENT
BTN_GHOST_BG = '#ffffff'
BTN_HOVER_PRIMARY = '#8b3bd1'
BTN_HOVER_ACCENT = '#9b6df0'

def create_button(parent, text, command=None, variant='primary', width=14, fg=BTN_FG, font=None):
    """Create a styled button.

    variant: 'primary' | 'accent' | 'ghost'
    """
    font = font or NORMAL_FONT
    if variant == 'primary':
        bg = BTN_PRIMARY
        hover = BTN_HOVER_PRIMARY
    elif variant == 'accent':
        bg = BTN_ACCENT
        hover = BTN_HOVER_ACCENT
    else:
        bg = BTN_GHOST_BG
        hover = '#f5f5f5'

    btn = tk.Button(parent, text=text, bg=bg, fg=fg, font=font, bd=0, width=width, command=command)
    make_hover(btn, hover)
    return btn


def create_card(parent, width=460, height=240, bg=None):
    """Create a simple card frame centered-ish for forms.

    Returns the card frame (tk.Frame) already placed using place (caller may override).
    """
    bg = bg or CARD_BG
    card = tk.Frame(parent, bg=bg, bd=0, relief='flat')
    return card
