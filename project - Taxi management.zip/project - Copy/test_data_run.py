import data

print('Before init: users', len(data.users_db), 'drivers', len(data.drivers_db), 'bookings', len(data.bookings))

data.init()
print('After init: users', len(data.users_db), 'drivers', len(data.drivers_db), 'bookings', len(data.bookings))
for b in data.bookings[:5]:
    print('BID:', b.get('id'), 'customer:', b.get('customer'))

if data.bookings and data.drivers_db:
    bid = data.bookings[0].get('id')
    driver = list(data.drivers_db.keys())[0]
    print('Attempting assign booking', bid, '->', driver)
    res = data.assign_booking(bid, driver)
    print('Assign result:', res)
    print('Booking now:', next((x for x in data.bookings if x.get('id')==bid), None))
