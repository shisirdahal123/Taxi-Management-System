import json
import os
import uuid

# ----- File Paths (resolved relative to this module) -----
BASE_DIR = os.path.dirname(__file__)
USERS_FILE = os.path.join(BASE_DIR, "users.json")
DRIVERS_FILE = os.path.join(BASE_DIR, "drivers.json")
BOOKINGS_FILE = os.path.join(BASE_DIR, "bookings.json")


# ----- Helper Functions -----

def load_json(filename):
    """Load JSON file or return empty dict/list."""
    if not os.path.exists(filename):
        if filename == BOOKINGS_FILE:
            return []  # bookings is a list
        return {}
    with open(filename, "r") as f:
        return json.load(f)


def save_json(filename, data):
    """Save dictionary or list to JSON."""
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)


# ----- In-memory Data (Cache) -----
users_db = {}
drivers_db = {}
admin_db = {"admin": "123"}
bookings = []

# ----- Current User Session -----
current_user = {
    "type": None,      
    "name": None,      
    "role": None       
}


# ----- User Session Functions -----

def set_current_user(user_type, name):
    global current_user
    current_user["type"] = user_type
    current_user["name"] = name
    current_user["role"] = user_type


def clear_current_user():
    global current_user
    current_user["type"] = None
    current_user["name"] = None
    current_user["role"] = None


def get_current_user():
    return current_user


# ----- Load Functions (Database → Memory) -----

def load_users():
    """Load users.json into the existing in-memory users_db dict.

    Mutate the existing dict instead of rebinding the name so external
    modules that hold a reference to `data.users_db` (aliases) continue to
    see updates.
    """
    global users_db
    loaded = load_json(USERS_FILE)
    if isinstance(loaded, dict):
        users_db.clear()
        users_db.update(loaded)
    else:
        users_db.clear()


def load_drivers():
    """Load drivers.json into the existing in-memory drivers_db dict.

    Mutate the existing dict instead of rebinding the name so aliases stay valid.
    """
    global drivers_db
    loaded = load_json(DRIVERS_FILE)
    if isinstance(loaded, dict):
        drivers_db.clear()
        drivers_db.update(loaded)
    else:
        drivers_db.clear()


def load_bookings():
    global bookings
    loaded = load_json(BOOKINGS_FILE)
    if isinstance(loaded, list):
        bookings.clear()
        bookings.extend(loaded)
    else:
        bookings.clear()

    # Ensure every booking has a unique id for later reference
    changed = False
    for b in bookings:
        if 'id' not in b:
            b['id'] = str(uuid.uuid4())
            changed = True
    if changed:
        save_bookings()


# ----- Save Functions (Memory → Database) -----

def save_users():
    save_json(USERS_FILE, users_db)


def save_drivers():
    save_json(DRIVERS_FILE, drivers_db)


def save_bookings():
    save_json(BOOKINGS_FILE, bookings)


# ----- Initialize on App Startup -----

def init():
    load_users()
    load_drivers()
    load_bookings()


# ----- Convenience Adders (Memory -> DB + save helpers) -----
def add_user(email, password):
    """Add a new customer user and persist to USERS_FILE.

    Returns True on success, False if user already exists.
    """
    global users_db
    if email in users_db:
        return False
    users_db[email] = {"password": password, "bookings": []}
    save_users()
    return True


def add_driver(username, password):
    """Add a new driver and persist to DRIVERS_FILE.

    Returns True on success, False if driver already exists.
    """
    global drivers_db
    if username in drivers_db:
        return False
    drivers_db[username] = {"password": password, "assigned": []}
    save_drivers()
    return True


def add_booking(customer, pickup, drop, date_str):
    """Create a booking record and persist to BOOKINGS_FILE and link to user.

    The booking is appended to the in-memory `bookings` list and also added
    to the customer's `bookings` list (if the user exists).
    """
    global bookings, users_db
    booking = {
        "id": str(uuid.uuid4()),
        "customer": customer,
        "pickup": pickup,
        "drop": drop,
        "date": date_str,
        "driver": "Not Assigned",
        "status": "Pending",
    }
    bookings.append(booking)
    # Also attach to user's booking list if present
    if customer in users_db:
        users_db[customer].setdefault("bookings", []).append(booking)
        save_users()
    save_bookings()
    return booking


def assign_booking(booking_id, driver_username):
    """Assign a driver to a booking by id.

    Returns True on success, False if booking or driver not found.
    """
    global bookings, drivers_db, users_db
    # find booking
    booking = next((b for b in bookings if b.get('id') == booking_id), None)
    if booking is None:
        return False
    if driver_username not in drivers_db:
        return False

    booking['driver'] = driver_username
    booking['status'] = 'Assigned'

    # attach to driver assigned list
    drivers_db.setdefault(driver_username, {}).setdefault('assigned', []).append(booking)
    # update user's booking entry if present
    cust = booking.get('customer')
    if cust in users_db:
        # find corresponding booking object in user's bookings (match by id when available)
        user_bookings = users_db[cust].setdefault('bookings', [])
        matched = next((ub for ub in user_bookings if ub.get('id') == booking_id), None)
        if matched:
            matched.update({'driver': driver_username, 'status': 'Assigned'})
        else:
            user_bookings.append(booking)

    save_drivers()
    save_users()
    save_bookings()
    return True
