import tkinter as tk
from tkinter import messagebox, ttk

# --------- Shared helpers & data (imported modules) ----------
import data
import ui_helpers as ui

# expose convenient names (modules are the single source of truth)
PRIMARY = ui.PRIMARY
ACCENT = ui.ACCENT
BG = ui.BG
CARD_BG = ui.CARD_BG
BTN_FG = ui.BTN_FG
HEAD_FONT = ui.HEAD_FONT
NORMAL_FONT = ui.NORMAL_FONT

# data aliases (refer to same dicts/lists in data.py)
users_db = data.users_db
drivers_db = data.drivers_db
admin_db = data.admin_db
bookings = data.bookings

_make_hover = ui.make_hover


# -------------------- Main App Window --------------------
class TaxiApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Taxi Booking System")
        self.root.geometry("600x420")
        self.root.configure(bg=BG)

        # Initialize database and load data
        data.init()

        self.main_screen()

    # -------------------- MAIN MENU --------------------
    def main_screen(self):
        # clear any previous session when returning to main menu
        data.clear_current_user()

        for widget in self.root.winfo_children():
            widget.destroy()

        # Header
        header = tk.Label(self.root, text="Taxi Booking System", font=HEAD_FONT, bg=BG, fg=PRIMARY)
        header.pack(pady=18)

        # Card with actions (web-like)
        card = tk.Frame(self.root, bg=CARD_BG, bd=0)
        card.place(relx=0.5, rely=0.52, anchor='c', width=440, height=220)

        btn_frame = tk.Frame(card, bg=CARD_BG)
        btn_frame.pack(expand=True)

        b1 = ui.create_button(btn_frame, "Customer Login", command=self.customer_login, variant='primary', width=18)
        b1.grid(row=0, column=0, padx=8, pady=12)
        b2 = ui.create_button(btn_frame, "Driver Login", command=self.driver_login, variant='accent', width=18)
        b2.grid(row=0, column=1, padx=8, pady=12)
        b3 = ui.create_button(btn_frame, "Admin Login", command=self.admin_login, variant='primary', width=38)
        b3.grid(row=1, column=0, columnspan=2, pady=(6, 0))
        _make_hover(b3, '#8b3bd1')

    # -------------------- CUSTOMER LOGIN --------------------
    def customer_login(self):
        # login_func will be called with (email, pwd) from the template
        def login(email, pwd):
            if email in users_db and users_db[email]["password"] == pwd:
                data.set_current_user("customer", email)
                messagebox.showinfo("Success", "Login Successful")
                self.customer_dashboard(email)
            else:
                messagebox.showerror("Error", "Invalid credentials")

        # pass customer register as the register callback
        self._login_template("Customer Login", login, show_register=True, register_callback=self.customer_register)

    # -------------------- DRIVER LOGIN --------------------
    def driver_login(self):
        def login(user, pwd):
            user_input = user.strip()
            # try case-insensitive match to be forgiving with casing
            match_key = None
            for k in drivers_db.keys():
                if k.lower() == user_input.lower():
                    match_key = k
                    break

            if match_key is None:
                messagebox.showerror("Not found", "Driver not found. Please register or check the username.")
                return

            # check password
            if drivers_db.get(match_key, {}).get("password") == pwd:
                data.set_current_user("driver", match_key)
                self.driver_dashboard(match_key)
            else:
                messagebox.showerror("Error", "Incorrect password for that driver")

        # Use _login_template with driver register callback
        def show_register():
            import driver
            driver.driver_register(self)

        self._login_template("Driver Login", login, show_register=True, register_callback=show_register)

    # -------------------- ADMIN LOGIN --------------------
    def admin_login(self):
        def login(user, pwd):
            if user in admin_db and admin_db[user] == pwd:
                data.set_current_user("admin", user)
                self.admin_dashboard()
            else:
                messagebox.showerror("Error", "Invalid Admin Credentials")

        self._login_template("Admin Login", login)

    # -------------------- LOGIN WINDOW TEMPLATE --------------------
    def _login_template(self, title, login_func, show_register=False, register_callback=None):
        for widget in self.root.winfo_children():
            widget.destroy()
        # header + card-style form
        header = tk.Label(self.root, text=title, font=HEAD_FONT, bg=BG, fg=PRIMARY)
        header.pack(pady=12)

        card = tk.Frame(self.root, bg=CARD_BG)
        card.place(relx=0.5, rely=0.58, anchor='c', width=480, height=260)

        frm = tk.Frame(card, bg=CARD_BG)
        frm.pack(padx=16, pady=12, fill='both', expand=True)

        tk.Label(frm, text="Email/Username", bg=CARD_BG, anchor='w', font=NORMAL_FONT).pack(fill='x')
        email_entry = tk.Entry(frm, font=NORMAL_FONT)
        email_entry.pack(fill='x', pady=(4, 8))

        tk.Label(frm, text="Password", bg=CARD_BG, anchor='w', font=NORMAL_FONT).pack(fill='x')
        pw_row = tk.Frame(frm, bg=CARD_BG)
        pw_row.pack(fill='x')
        pass_entry = tk.Entry(pw_row, show='*', font=NORMAL_FONT)
        pass_entry.pack(side='left', fill='x', expand=True, pady=(4, 8))

        # show/hide toggle
        def _toggle():
            if pass_entry.cget('show') == '*':
                pass_entry.config(show='')
                toggle_btn.config(text='Hide')
            else:
                pass_entry.config(show='*')
                toggle_btn.config(text='Show')

        toggle_btn = tk.Button(pw_row, text='Show', command=_toggle, bg='#eee', bd=0)
        toggle_btn.pack(side='left', padx=(6, 0), pady=(4, 8))

        action_row = tk.Frame(frm, bg=CARD_BG)
        action_row.pack(pady=(6, 0))

        login_btn = ui.create_button(action_row, 'Login', command=lambda: login_func(email_entry.get().strip(), pass_entry.get()), variant='primary', width=12)
        login_btn.pack(side='left', padx=8)
        clear_btn = ui.create_button(action_row, 'Clear', command=lambda: (email_entry.delete(0, tk.END), pass_entry.delete(0, tk.END), email_entry.focus()), variant='accent', width=12)
        clear_btn.pack(side='left', padx=8)

        # Bottom action row for Register / Back
        bottom_row = tk.Frame(card, bg=CARD_BG)
        bottom_row.pack(side='bottom', pady=8)
        if show_register:
            cb = register_callback if callable(register_callback) else self.customer_register
            reg_btn = tk.Button(bottom_row, text="Register", bg=ui.BACK_BG, command=cb, bd=0, width=12)
            reg_btn.pack(side='left', padx=8)
        back_btn = ui.make_back(bottom_row, 'Back', self.main_screen)
        back_btn.pack(side='left', padx=8)

    # -------------------- CUSTOMER REGISTER --------------------
    def customer_register(self):
        # delegate to customer module UI
        import customer
        customer.customer_register(self)

    # -------------------- CUSTOMER DASHBOARD --------------------
    def customer_dashboard(self, email):
        # delegate to customer module
        import customer
        customer.customer_dashboard(self, email)

    # -------------------- BOOK TAXI --------------------
    def book_taxi(self, email):
        import customer
        customer.book_taxi(self, email)

    # -------------------- VIEW CUSTOMER BOOKINGS --------------------
    def view_customer_bookings(self, email):
        import customer
        customer.view_customer_bookings(self, email)

    # -------------------- ADMIN DASHBOARD --------------------
    def admin_dashboard(self):
        import admin
        admin.admin_dashboard(self)

    # -------------------- ADMIN VIEW BOOKINGS --------------------
    def admin_view_bookings(self):
        import admin
        admin.admin_view_bookings(self)

    # -------------------- DRIVER DASHBOARD --------------------
    def driver_dashboard(self, driver):
        import driver as driver_module
        driver_module.driver_dashboard(self, driver)

    # -------------------- DRIVER VIEW TRIPS --------------------
    def driver_view_trips(self, driver):
        import driver as driver_module
        driver_module.driver_view_trips(self, driver)


# -------------------- RUN APP --------------------
root = tk.Tk()
app = TaxiApp(root)
root.mainloop()
